import { createFileRoute } from "@tanstack/react-router";
import { useScrollReveal } from "@/hooks/use-scroll-reveal";
import { Nav } from "@/components/landing/Nav";
import { Hero } from "@/components/landing/Hero";
import { Problem } from "@/components/landing/Problem";
import { CostNumbers } from "@/components/landing/CostNumbers";
import { Systems } from "@/components/landing/Systems";
import { Included } from "@/components/landing/Included";
import { Pricing } from "@/components/landing/Pricing";
import { NotWhat } from "@/components/landing/NotWhat";
import { HowItWorks } from "@/components/landing/HowItWorks";
import { WhoFor } from "@/components/landing/WhoFor";
import { Outcomes } from "@/components/landing/Outcomes";
import { Faq } from "@/components/landing/Faq";
import { FinalCta } from "@/components/landing/FinalCta";
import { Footer } from "@/components/landing/Footer";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ARK — Recover the Revenue Already Inside Your Agency's Book" },
      {
        name: "description",
        content:
          "ARK runs the lead response, quote follow-up, renewal protection, and cross-sell systems behind independent P&C agencies on HawkSoft & EZLynx — recovering revenue without hiring.",
      },
      { property: "og:title", content: "ARK — Recover the Revenue Already Inside Your Book" },
      {
        property: "og:description",
        content:
          "Four managed systems. One outcome: more revenue from the business you already have. Live in two weeks.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  useScrollReveal();
  return (
    <div className="min-h-screen bg-background">
      <Nav />
      <main>
        <Hero />
        <Problem />
        <CostNumbers />
        <Systems />
        <Included />
        <Pricing />
        <NotWhat />
        <HowItWorks />
        <WhoFor />
        <Outcomes />
        <Faq />
        <FinalCta />
      </main>
      <Footer />
    </div>
  );
}
