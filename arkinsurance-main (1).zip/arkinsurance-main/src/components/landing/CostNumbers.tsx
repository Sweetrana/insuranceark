import { SectionHeading } from "./Section";

const numbers = [
  {
    value: "$120",
    label: "Lost before your producer picks up the phone — just from responding the next morning instead of within the hour.",
  },
  {
    value: "25–35%",
    label: "Your current quote-to-bind ratio. Top agencies using systematic follow-up hit 50%+. The difference isn't better rates.",
    highlight: true,
  },
  {
    value: "$440K",
    label: "In premium lost annually at a 22% lapse rate on a $2M book. Not because clients are unhappy — because no one reached out.",
  },
  {
    value: "Hundreds",
    label: "Of cross-sell opportunities sitting in your AMS right now — auto but not home, home but not umbrella. Untouched.",
  },
];

export function CostNumbers() {
  return (
    <section className="relative overflow-hidden bg-gradient-ink py-20 text-ink-foreground sm:py-28">
      <div className="absolute inset-0 grid-faint-dark opacity-60" aria-hidden />
      <div
        className="pointer-events-none absolute right-[-6%] top-1/3 h-[360px] w-[360px] rounded-full bg-gold/12 blur-[130px]"
        aria-hidden
      />
      <div data-reveal className="relative mx-auto max-w-6xl px-5 sm:px-8">
        <div className="max-w-2xl">
          <span className="inline-flex items-center gap-2 rounded-full border border-gold/30 bg-gold/10 px-3.5 py-1.5 text-xs font-bold uppercase tracking-wider text-gold-soft">
            <span className="h-1.5 w-1.5 rounded-full bg-gold" /> The math is real
          </span>
          <h2 className="mt-4 font-display text-3xl font-bold leading-[1.1] tracking-tight sm:text-4xl lg:text-[2.75rem]">
            What this actually costs you — in numbers.
          </h2>
          <p className="mt-4 text-base leading-relaxed text-ink-muted sm:text-lg">
            You're spending <span className="font-semibold text-ink-foreground">$400 per lead</span> on
            average. The math on what slips through is real.
          </p>
        </div>

        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {numbers.map((n) => (
            <div
              key={n.value}
              className={`relative flex flex-col rounded-2xl border p-6 transition-transform hover:-translate-y-1 ${
                n.highlight
                  ? "border-gold/40 bg-gold/10 shadow-[0_20px_50px_-20px_oklch(0.81_0.12_78_/_0.5)]"
                  : "border-ink-foreground/10 bg-ink-foreground/[0.04]"
              }`}
            >
              <p
                className={`font-display text-5xl font-bold leading-none lg:text-[3.25rem] ${
                  n.highlight ? "text-gold" : "text-ink-foreground"
                }`}
              >
                {n.value}
              </p>
              <p className="mt-4 text-sm leading-relaxed text-ink-muted">{n.label}</p>
            </div>
          ))}
        </div>

        <p className="mt-12 max-w-3xl text-lg leading-relaxed text-ink-muted">
          The problem isn't effort. Your team is working hard. The problem is that the revenue your agency
          is capable of generating requires a level of follow-through that human beings running on{" "}
          <span className="font-semibold text-ink-foreground">sticky notes</span> simply cannot maintain
          consistently.
        </p>
      </div>
    </section>
  );
}
