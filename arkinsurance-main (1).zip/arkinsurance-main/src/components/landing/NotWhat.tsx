import { X } from "lucide-react";
import { SectionHeading } from "./Section";

const items = [
  {
    title: "Not a chatbot",
    body: "We're not putting a widget on your website that answers FAQs and frustrates clients. Every touchpoint sounds like it came from your agency, not a robot.",
  },
  {
    title: "Not software",
    body: "You don't get a login and a tutorial video and a good luck. We build the systems, configure them to your agency, and hand you something that works.",
  },
  {
    title: "Not generic",
    body: "We're not running the same workflow for a landscaping company and an insurance agency. Everything is specific to the lead-to-policy lifecycle of an independent P&C agency.",
  },
  {
    title: "Not a project for your team",
    body: "Your CSR doesn't need to learn anything new. Your producers don't change how they work. The systems run in the background and surface the right info at the right time.",
  },
];

export function NotWhat() {
  return (
    <section className="bg-secondary/50 py-20 sm:py-28">
      <div data-reveal className="mx-auto max-w-6xl px-5 sm:px-8">
        <SectionHeading
          eyebrow="Let's be clear"
          align="center"
          title={
            <>
              Before you ask — here's what ARK <span className="font-display font-semibold">isn't.</span>
            </>
          }
        />
        <div className="mt-14 grid gap-5 sm:grid-cols-2">
          {items.map((it) => (
            <div
              key={it.title}
              className="flex gap-4 rounded-2xl border border-border bg-card p-6 shadow-[var(--shadow-card)] sm:p-7"
            >
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-danger/10 text-danger">
                <X className="h-5 w-5" strokeWidth={2.6} />
              </span>
              <div>
                <h3 className="font-display text-xl font-semibold tracking-tight text-foreground">
                  {it.title}
                </h3>
                <p className="mt-2 text-[0.95rem] leading-relaxed text-muted-foreground">{it.body}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
