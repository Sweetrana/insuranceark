import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { SectionHeading } from "./Section";

const faqs = [
  {
    q: "We've tried automation before. It broke.",
    a: "You tried tools. ARK isn't a tool — it's a managed service. We own the outcome, not just the tech.",
  },
  {
    q: "We already have GoHighLevel / a CRM.",
    a: "Good. We build inside what you already have wherever possible. We're not asking you to replace anything — we're building the workflows your tools were designed for but nobody had time to set up properly.",
  },
  {
    q: "Our agency is too small / too big.",
    a: "If you have 2+ producers and care about the revenue leaking out of your existing book, ARK pays for itself. Period.",
  },
  {
    q: "What if our AMS isn't supported?",
    a: "Book a discovery call and tell us what you're running. We support HawkSoft, EZLynx, and AgencyZoom natively. For others, we'll tell you honestly what's possible.",
  },
  {
    q: "Is the $497 audit worth it if we don't move forward?",
    a: "Yes. You walk away with a specific, documented picture of where your agency is leaking revenue and a roadmap for fixing it — whether you use us or someone else. Most agency owners find that alone is worth the conversation.",
  },
  {
    q: "How is this different from other vendors?",
    a: "Most vendors focus on implementing software. We focus on making sure leads, renewals, and cross-sell opportunities are consistently worked and followed up. Many of our clients run both.",
  },
  {
    q: "What if it doesn't work?",
    a: "The audit alone gives you a roadmap you can act on with or without us. From there, we agree on the outcomes we'll be measured against — in writing.",
  },
];

export function Faq() {
  return (
    <section id="faq" className="bg-secondary/50 py-20 sm:py-28">
      <div data-reveal className="mx-auto max-w-3xl px-5 sm:px-8">
        <SectionHeading eyebrow="FAQ" align="center" title="The questions we hear most often." />

        <Accordion type="single" collapsible className="mt-12 space-y-3">
          {faqs.map((f, i) => (
            <AccordionItem
              key={i}
              value={`item-${i}`}
              className="rounded-2xl border border-border bg-card px-5 shadow-[var(--shadow-card)] data-[state=open]:border-emerald/40"
            >
              <AccordionTrigger className="py-5 text-left font-display text-lg font-semibold tracking-tight text-foreground hover:no-underline">
                {f.q}
              </AccordionTrigger>
              <AccordionContent className="pb-5 text-[0.975rem] leading-relaxed text-muted-foreground">
                {f.a}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
}
