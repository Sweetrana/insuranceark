import { Check, Zap, ClipboardList, ShieldCheck, Layers } from "lucide-react";
import { SectionHeading } from "./Section";

const included = [
  {
    icon: Zap,
    name: "Lead Response System",
    items: ["Instant email response", "Instant SMS response", "Lead routing", "Pipeline creation", "Internal notifications"],
  },
  {
    icon: ClipboardList,
    name: "Quote Follow-Up System",
    items: ["Automated follow-up sequences", "Quote reminders", "Re-engagement campaigns", "Producer alerts"],
  },
  {
    icon: ShieldCheck,
    name: "Renewal Protection System",
    items: ["90-day renewal reminders", "Renewal communication workflows", "Producer task creation", "Escalation reminders"],
  },
  {
    icon: Layers,
    name: "Cross-Sell Opportunity System",
    items: ["Coverage review campaigns", "Opportunity tagging", "Cross-sell reminders", "Book review workflows"],
  },
];

export function Included() {
  return (
    <section className="bg-secondary/50 py-20 sm:py-28">
      <div data-reveal className="mx-auto max-w-6xl px-5 sm:px-8">
        <SectionHeading
          eyebrow="What's included"
          align="center"
          title="Everything in every ARK implementation."
          intro="Every ARK implementation includes the four core systems built to recover revenue from your existing book."
        />

        <div className="mt-14 grid gap-5 sm:grid-cols-2">
          {included.map((sys) => (
            <div
              key={sys.name}
              className="rounded-3xl border border-border bg-card p-7 shadow-[var(--shadow-card)]"
            >
              <div className="flex items-center gap-3 border-b border-border pb-5">
                <span className="grid h-11 w-11 place-items-center rounded-xl bg-ink text-ink-foreground">
                  <sys.icon className="h-5 w-5" strokeWidth={2.2} />
                </span>
                <h3 className="font-display text-xl font-semibold tracking-tight text-foreground">
                  {sys.name}
                </h3>
              </div>
              <ul className="mt-5 space-y-3">
                {sys.items.map((item) => (
                  <li key={item} className="flex items-center gap-3 text-[0.975rem] text-foreground/85">
                    <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full bg-emerald/15 text-emerald-deep">
                      <Check className="h-3.5 w-3.5" strokeWidth={3} />
                    </span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
