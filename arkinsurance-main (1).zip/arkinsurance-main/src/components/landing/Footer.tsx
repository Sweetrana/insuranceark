import { Logo } from "./Logo";

export function Footer() {
  return (
    <footer className="border-t border-border bg-background py-10">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-5 px-5 sm:flex-row sm:px-8">
        <Logo />
        <p className="text-center text-sm text-muted-foreground sm:text-right">
          ARK Revenue &amp; Retention System — for independent P&amp;C agencies on HawkSoft, EZLynx &amp;
          AgencyZoom.
          <br className="hidden sm:block" />
          <span className="text-xs">© {new Date().getFullYear()} ARK. All rights reserved.</span>
        </p>
      </div>
    </footer>
  );
}
