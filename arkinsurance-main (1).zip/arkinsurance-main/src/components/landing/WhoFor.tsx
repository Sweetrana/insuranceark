import { Check } from "lucide-react";

const criteria = [
  "Run on HawkSoft, EZLynx or AgencyZoom",
  "Have at least 2 producers or $1M+ in written premium",
  "Are growing but plateauing on follow-through, not lead flow",
  "Don't want to hire their way out of the problem",
];

export function WhoFor() {
  return (
    <section className="relative overflow-hidden bg-gradient-ink py-20 text-ink-foreground sm:py-28">
      <div className="absolute inset-0 grid-faint-dark opacity-60" aria-hidden />
      <div
        className="pointer-events-none absolute left-1/2 top-0 h-72 w-72 -translate-x-1/2 rounded-full bg-emerald/20 blur-[120px]"
        aria-hidden
      />
      <div data-reveal className="relative mx-auto max-w-4xl px-5 text-center sm:px-8">
        <span className="inline-flex items-center gap-2 rounded-full border border-emerald/30 bg-emerald/10 px-3.5 py-1.5 text-xs font-bold uppercase tracking-wider text-emerald">
          <span className="h-1.5 w-1.5 rounded-full bg-emerald" /> Who this is for
        </span>
        <h2 className="mt-5 font-display text-3xl font-bold leading-tight tracking-tight sm:text-4xl">
          ARK is built for independent P&amp;C agencies that…
        </h2>

        <div className="mt-10 grid gap-4 text-left sm:grid-cols-2">
          {criteria.map((c, i) => (
            <div
              key={c}
              className="flex items-center gap-4 rounded-2xl border border-ink-foreground/10 bg-ink-foreground/[0.04] p-5"
            >
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-gradient-emerald font-display text-base font-bold text-emerald-foreground">
                {i + 1}
              </span>
              <span className="text-[0.975rem] font-medium leading-snug text-ink-foreground/90">{c}</span>
            </div>
          ))}
        </div>

        <p className="mx-auto mt-10 max-w-xl font-display text-xl font-bold leading-snug text-gold-soft sm:text-2xl">
          If that's you, the audit will pay for itself before the report is finished.
        </p>
      </div>
    </section>
  );
}
