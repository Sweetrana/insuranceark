import { SectionHeading } from "./Section";

const phases = [
  {
    when: "Week 1–2",
    text: "Build and configuration. You don't need to be involved much. We handle it.",
  },
  {
    when: "Week 3",
    text: "Go live. Leads start getting responded to in under a minute. Quotes get followed up automatically. Renewal sequences start running.",
  },
  {
    when: "Month 1",
    text: "Your producers stop chasing. Your CSR stops manually sending reminders. You stop wondering whether anyone followed up.",
  },
  {
    when: "Month 3",
    text: "Your renewal retention improves visibly. Your quote-to-bind ratio moves. You have data on what's working.",
  },
  {
    when: "Ongoing",
    text: "Monthly optimization. We review what's performing, adjust sequences, and expand automation as your agency grows.",
  },
];

export function Outcomes() {
  return (
    <section className="py-20 sm:py-28">
      <div data-reveal className="mx-auto max-w-5xl px-5 sm:px-8">
        <SectionHeading
          eyebrow="The outcomes"
          align="center"
          title="What changes with ARK in place."
        />

        <div className="mt-14 space-y-4">
          {phases.map((p, i) => (
            <div
              key={p.when}
              className="flex flex-col gap-3 rounded-2xl border border-border bg-card p-6 shadow-[var(--shadow-card)] sm:flex-row sm:items-center sm:gap-6 sm:p-7"
            >
              <div className="flex shrink-0 items-center gap-3 sm:w-44">
                <span className="font-display text-3xl font-bold text-muted/70">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <span className="rounded-full bg-emerald/12 px-3 py-1 text-sm font-bold text-emerald-deep">
                  {p.when}
                </span>
              </div>
              <p className="text-[0.975rem] leading-relaxed text-foreground/85">{p.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
