import { SectionHeading } from "./Section";

const steps = [
  {
    n: "01",
    tag: "15–30 Minutes",
    title: "Free Discovery Call",
    body: "We'll identify where opportunities are slipping through the cracks and determine whether ARK is a fit.",
    items: [],
  },
  {
    n: "02",
    tag: "$497 — credited toward implementation",
    title: "Agency Revenue Leak Audit",
    body: "If there's a fit, we conduct a deeper review of your lead response, follow-up, renewals, and cross-sell process.",
    items: ["Revenue Leak Report", "Follow-Through Assessment", "90-Day Improvement Roadmap"],
    note: "Most agency owners tell us this audit alone is worth 10x the fee.",
  },
  {
    n: "03",
    tag: "3 Weeks",
    title: "The Build",
    body: "We build the four ARK systems into your existing AMS and tech stack. No 'rip and replace.' No 6-month implementation. You're live in 21 days.",
    items: [],
  },
  {
    n: "04",
    tag: "Ongoing",
    title: "The Manage",
    body: "We monitor, optimize, and improve every system every week. You get a monthly report showing exactly what's working — leads worked, quotes followed up, renewals protected, cross-sell surfaced, and the premium impact behind each.",
    items: [],
  },
];

export function HowItWorks() {
  return (
    <section id="how" className="py-20 sm:py-28">
      <div data-reveal className="mx-auto max-w-6xl px-5 sm:px-8">
        <SectionHeading
          eyebrow="How it works"
          align="center"
          title="From first call to live systems in under a month."
        />

        <div className="relative mt-14">
          <div
            className="absolute left-[27px] top-4 bottom-4 hidden w-px bg-gradient-to-b from-emerald via-border to-border lg:block"
            aria-hidden
          />
          <div className="space-y-5">
            {steps.map((s) => (
              <div key={s.n} className="relative flex flex-col gap-5 lg:flex-row lg:items-stretch">
                <div className="z-10 flex shrink-0 items-center gap-4 lg:w-14 lg:flex-col">
                  <span className="grid h-14 w-14 place-items-center rounded-2xl bg-gradient-emerald font-display text-xl font-bold text-emerald-foreground shadow-[var(--shadow-glow)]">
                    {s.n}
                  </span>
                </div>
                <div className="flex-1 rounded-2xl border border-border bg-card p-6 shadow-[var(--shadow-card)] sm:p-7">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <h3 className="font-display text-2xl font-semibold tracking-tight text-foreground">
                      {s.title}
                    </h3>
                    <span className="rounded-full bg-gold/15 px-3 py-1 text-xs font-bold uppercase tracking-wide text-gold-foreground">
                      {s.tag}
                    </span>
                  </div>
                  <p className="mt-3 text-[0.975rem] leading-relaxed text-muted-foreground">{s.body}</p>
                  {s.items.length > 0 && (
                    <div className="mt-4 flex flex-wrap gap-2">
                      {s.items.map((it) => (
                        <span
                          key={it}
                          className="rounded-lg border border-emerald/25 bg-emerald/8 px-3 py-1.5 text-sm font-semibold text-emerald-deep"
                        >
                          {it}
                        </span>
                      ))}
                    </div>
                  )}
                  {s.note && (
                    <p className="mt-4 border-l-2 border-gold pl-3 text-sm font-medium italic text-foreground/70">
                      {s.note}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
