import { ArrowRight, Check } from "lucide-react";
import { Button } from "@/components/ui/button";

const points = ["Discovery call is free", "$497 audit, fully credited", "Most agencies live in two weeks"];

export function FinalCta() {
  return (
    <section id="contact" className="relative overflow-hidden bg-gradient-ink py-24 text-ink-foreground sm:py-32">
      <div className="absolute inset-0 grid-faint-dark opacity-60" aria-hidden />
      <div
        className="pointer-events-none absolute right-[-8%] top-[-10%] h-96 w-96 rounded-full bg-emerald/22 blur-[130px]"
        aria-hidden
      />
      <div
        className="pointer-events-none absolute bottom-[-15%] left-[-8%] h-80 w-80 rounded-full bg-gold/12 blur-[130px]"
        aria-hidden
      />
      <div data-reveal className="relative mx-auto max-w-4xl px-5 text-center sm:px-8">
        <h2 className="font-display text-4xl font-bold leading-[1.08] tracking-tight sm:text-5xl lg:text-6xl">
          You can hire 2 more producers.
          <br />
          Or you can unlock the revenue{" "}
          <span className="text-gradient-emerald font-semibold">already sitting inside your book.</span>
        </h2>
        <p className="mx-auto mt-6 max-w-2xl text-base leading-relaxed text-ink-muted sm:text-lg">
          Every week without these systems is another week of leads going cold, quotes being forgotten,
          and renewals slipping quietly away. The discovery call is free. The audit is $497 and fully
          credited toward implementation.
        </p>

        <div className="mt-9 flex justify-center">
          <Button variant="hero" size="xl" asChild>
            <a href="#contact">
              Book a Free Discovery Call <ArrowRight className="h-5 w-5" />
            </a>
          </Button>
        </div>

        <div className="mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm text-ink-muted">
          {points.map((p) => (
            <span key={p} className="inline-flex items-center gap-2">
              <Check className="h-4 w-4 text-emerald" /> {p}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
