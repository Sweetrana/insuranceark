import { AlertTriangle } from "lucide-react";
import { SectionHeading } from "./Section";

const timeline = [
  {
    when: "8:43 PM · Tuesday",
    text: "A prospect submits a quote request. Your office is closed. They get an auto-reply. By 9 AM Wednesday, they've already spoken to two other agents.",
  },
  {
    when: "Wednesday morning",
    text: "Your CSR spends the first two hours copying info from emails into your AMS, chasing missing fields, and sending renewal reminders from a spreadsheet she made herself.",
  },
  {
    when: "Same morning",
    text: "Your producer — the one you're paying $120K to close business — spent forty-five minutes entering VINs.",
  },
  {
    when: "Three weeks ago",
    text: "A quote went out Thursday. The prospect said they'd think about it. Nobody followed up. That policy is bound somewhere else.",
  },
  {
    when: "This renewal season",
    text: "A six-year client didn't get a renewal call. Not on purpose — the phones were ringing and it slipped. They shopped around. You found out when they called to cancel.",
  },
];

export function Problem() {
  return (
    <section id="problem" className="relative overflow-hidden py-20 sm:py-28">
      <div className="absolute inset-0 grid-faint opacity-60" aria-hidden />
      <div data-reveal className="relative mx-auto max-w-6xl px-5 sm:px-8">
        <SectionHeading
          eyebrow="The real problem"
          title={
            <>
              You don't have a lead problem.
              <br className="hidden sm:block" /> You have a{" "}
              <span className="font-display font-semibold text-emerald-deep">follow-through</span> problem.
            </>
          }
          intro={
            <>
              Most agencies think they need more marketing. They don't. They need to actually work the
              leads, quotes, renewals, and clients they already have — consistently, without relying on
              someone to remember.
            </>
          }
        />

        <p className="mt-10 text-sm font-bold uppercase tracking-wider text-muted-foreground">
          Here's what's really happening inside your agency this week
        </p>

        <div className="mt-6 grid gap-4 lg:grid-cols-2">
          {timeline.map((t, i) => (
            <div
              key={i}
              className={`group relative rounded-2xl border border-border bg-card p-6 shadow-[var(--shadow-card)] transition-transform hover:-translate-y-0.5 ${
                i === timeline.length - 1 && timeline.length % 2 !== 0 ? "lg:col-span-2" : ""
              }`}
            >
              <span className="absolute left-0 top-6 h-10 w-1 rounded-r bg-gradient-to-b from-danger to-gold" />
              <p className="pl-3 text-xs font-bold uppercase tracking-wider text-danger">{t.when}</p>
              <p className="mt-2 pl-3 text-[0.975rem] leading-relaxed text-foreground/80">{t.text}</p>
            </div>
          ))}
        </div>

        <div className="mt-10 flex flex-col items-start gap-4 rounded-2xl bg-gradient-ink p-7 text-ink-foreground sm:flex-row sm:items-center sm:p-8">
          <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-gold/20 text-gold">
            <AlertTriangle className="h-6 w-6" />
          </span>
          <p className="font-display text-xl font-bold leading-snug sm:text-2xl">
            Every one of these is a follow-through leak — not a software problem.{" "}
            <span className="text-gradient-emerald font-semibold">ARK plugs them.</span>
          </p>
        </div>
      </div>
    </section>
  );
}
