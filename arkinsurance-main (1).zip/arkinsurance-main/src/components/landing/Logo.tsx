import { Anchor } from "lucide-react";

export function Logo({ tone = "ink" }: { tone?: "ink" | "light" }) {
  const text = tone === "light" ? "text-ink-foreground" : "text-foreground";
  return (
    <a href="#top" className="group inline-flex items-center gap-2.5" aria-label="ARK home">
      <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-emerald text-emerald-foreground shadow-[var(--shadow-glow)]">
        <Anchor className="h-5 w-5" strokeWidth={2.4} />
      </span>
      <span className={`font-display text-2xl font-semibold tracking-tight ${text}`}>
        ARK
        <span className="text-emerald">.</span>
      </span>
    </a>
  );
}
