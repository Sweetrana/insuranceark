import { ArrowRight, Check } from "lucide-react";
import { Button } from "@/components/ui/button";

const included = [
  "Lead Response System",
  "Quote Follow-Up System",
  "Renewal Protection System",
  "Cross-Sell Opportunity System",
  "Setup & Configuration",
  "Monthly Optimization",
];

export function Pricing() {
  return (
    <section id="pricing" className="py-20 sm:py-28">
      <div data-reveal className="mx-auto max-w-6xl px-5 sm:px-8">
        <div className="overflow-hidden rounded-[2rem] border border-border shadow-[var(--shadow-elegant)]">
          <div className="grid lg:grid-cols-[1.1fr_0.9fr]">
            {/* Left: offer */}
            <div className="bg-card p-8 sm:p-10 lg:p-12">
              <span className="inline-flex items-center gap-2 rounded-full border border-emerald/30 bg-emerald/8 px-3.5 py-1.5 text-xs font-bold uppercase tracking-wider text-emerald-deep">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald" /> One offer. Built for results.
              </span>
              <h2 className="mt-5 font-display text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
                ARK Revenue &amp; Retention System
              </h2>

              <div className="mt-7 flex items-end gap-3">
                <span className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
                  Starts at
                </span>
                <span className="font-display text-6xl font-bold leading-none text-foreground">
                  $2,000
                </span>
                <span className="pb-1.5 text-sm font-medium text-muted-foreground">setup</span>
              </div>
              <p className="mt-3 text-sm text-muted-foreground">
                Final pricing depends on agency size, team structure, and workflow complexity.
              </p>

              <div className="mt-8 grid gap-3 sm:grid-cols-2">
                {included.map((item) => (
                  <div key={item} className="flex items-center gap-3 text-[0.95rem] text-foreground/90">
                    <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full bg-emerald text-emerald-foreground">
                      <Check className="h-3.5 w-3.5" strokeWidth={3} />
                    </span>
                    {item}
                  </div>
                ))}
              </div>
            </div>

            {/* Right: CTA path */}
            <div className="relative flex flex-col justify-center overflow-hidden bg-gradient-ink p-8 text-ink-foreground sm:p-10 lg:p-12">
              <div
                className="pointer-events-none absolute right-[-20%] top-[-20%] h-64 w-64 rounded-full bg-emerald/25 blur-[100px]"
                aria-hidden
              />
              <p className="relative text-sm font-semibold uppercase tracking-wider text-gold-soft">
                Your next step
              </p>
              <p className="relative mt-4 font-display text-2xl font-bold leading-snug">
                Start with a{" "}
                <span className="text-gradient-emerald font-semibold">free discovery call.</span> If there's a
                fit, we'll move to a $497 Revenue Leak Audit — fully credited toward your implementation.
              </p>

              <div className="relative mt-7 flex items-center gap-4 rounded-2xl border border-ink-foreground/10 bg-ink-foreground/[0.05] p-5">
                <span className="font-display text-4xl font-bold text-gold">$497</span>
                <span className="text-sm text-ink-muted">
                  Revenue Leak Audit
                  <br />
                  <span className="font-semibold text-ink-foreground">100% credited to implementation</span>
                </span>
              </div>

              <Button variant="hero" size="xl" asChild className="relative mt-7 w-full">
                <a href="#contact">
                  Book a Free Discovery Call <ArrowRight className="h-5 w-5" />
                </a>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
