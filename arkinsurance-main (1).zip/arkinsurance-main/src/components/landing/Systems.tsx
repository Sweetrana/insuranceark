import { Zap, ClipboardList, ShieldCheck, Layers, ArrowUpRight } from "lucide-react";
import { SectionHeading } from "./Section";

const systems = [
  {
    icon: Zap,
    name: "Lead Response System",
    body: "A prospect requests a quote at 8:37 PM. By 8:38 PM they've received a personal-sounding response, entered your pipeline, been assigned to the right producer, and started a follow-up sequence that keeps them warm until someone can call.",
    kicker: "Your agency never looks closed again.",
    metric: "<60s",
    metricLabel: "Response Time",
  },
  {
    icon: ClipboardList,
    name: "Quote Follow-Up System",
    body: "Every open quote enters a structured sequence — Day 1, 3, 7, 14. Each touchpoint is timed and personalized. The moment a prospect responds, the sequence stops and your producer is notified with full context.",
    kicker: "Your team only steps in when the lead is ready to talk. Not to chase.",
    metric: "50%+",
    metricLabel: "More Binds",
  },
  {
    icon: ShieldCheck,
    name: "Renewal Protection System",
    body: "ARK tracks every upcoming renewal, prioritizes by risk and premium size, and triggers outreach at 90, 60, 30, and 14 days out. Clients feel taken care of before they think about shopping.",
    kicker: "No more renewals slipping through because it was a busy week.",
    metric: "22%→",
    metricLabel: "Lapse Recovered",
  },
  {
    icon: Layers,
    name: "Cross-Sell Opportunity System",
    body: "ARK identifies mono-line clients, coverage gaps, and high-probability cross-sell opportunities — and keeps them visible in your pipeline so they don't disappear into a spreadsheet no one opens.",
    kicker: "Your producers get a prioritized list. Not guesswork.",
    metric: "8X",
    metricLabel: "ROI Potential",
  },
];

export function Systems() {
  return (
    <section id="systems" className="py-20 sm:py-28">
      <div data-reveal className="mx-auto max-w-6xl px-5 sm:px-8">
        <SectionHeading
          eyebrow="What ARK does"
          align="center"
          title={
            <>
              Four Systems. One Outcome:{" "}
              <span className="text-gradient-emerald font-semibold">More Revenue</span> From The Business You
              Already Have.
            </>
          }
        />

        <div className="mt-14 grid gap-6 lg:grid-cols-2">
          {systems.map((s, i) => (
            <article
              key={s.name}
              className="group relative flex flex-col overflow-hidden rounded-3xl border border-border bg-card p-7 shadow-[var(--shadow-card)] transition-all hover:-translate-y-1 hover:shadow-[var(--shadow-elegant)] sm:p-8"
            >
              <span className="absolute right-6 top-6 font-display text-6xl font-bold text-muted/60">
                {String(i + 1).padStart(2, "0")}
              </span>
              <span className="grid h-14 w-14 place-items-center rounded-2xl bg-gradient-emerald text-emerald-foreground shadow-[var(--shadow-glow)]">
                <s.icon className="h-7 w-7" strokeWidth={2.2} />
              </span>
              <h3 className="mt-5 font-display text-2xl font-semibold tracking-tight text-foreground">
                {s.name}
              </h3>
              <p className="mt-3 text-[0.975rem] leading-relaxed text-muted-foreground">{s.body}</p>
              <p className="mt-4 text-[0.975rem] font-semibold text-foreground">{s.kicker}</p>

              <div className="mt-6 flex items-center justify-between rounded-2xl border border-emerald/20 bg-emerald/8 px-5 py-4">
                <div className="flex items-center gap-3">
                  <ArrowUpRight className="h-5 w-5 text-emerald-deep" />
                  <span className="text-sm font-semibold uppercase tracking-wide text-emerald-deep">
                    Result
                  </span>
                </div>
                <div className="text-right">
                  <p className="font-display text-3xl font-bold leading-none text-emerald-deep">
                    {s.metric}
                  </p>
                  <p className="text-xs font-medium text-muted-foreground">{s.metricLabel}</p>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
