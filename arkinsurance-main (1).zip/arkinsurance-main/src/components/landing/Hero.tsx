import { ArrowRight, Check, Clock, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";

const stats = [
  {
    value: "30–40%",
    label: "of leads lost when you respond the next morning instead of now",
  },
  {
    value: "$300K+",
    label: "in premium walking out the door annually on a $2M book via manual renewals",
  },
  {
    value: "50%+",
    label: "quote-to-bind rate at top agencies using systematic follow-up",
  },
];

const feed = [
  { time: "8:37 PM", text: "Quote request received — auto-insurance", tone: "in" },
  { time: "8:38 PM", text: "Personal response sent · producer assigned", tone: "out" },
  { time: "8:38 PM", text: "Follow-up sequence started (Day 1 / 3 / 7)", tone: "seq" },
  { time: "Day 3", text: "Prospect replied → producer notified with context", tone: "win" },
];

export function Hero() {
  return (
    <section id="top" className="relative overflow-hidden bg-gradient-ink pt-28 pb-20 sm:pt-32 lg:pb-28">
      <div className="absolute inset-0 grid-faint-dark opacity-70" aria-hidden />
      <div
        className="pointer-events-none absolute -top-40 right-[-10%] h-[460px] w-[460px] rounded-full bg-emerald/25 blur-[120px]"
        aria-hidden
      />
      <div
        className="pointer-events-none absolute bottom-[-20%] left-[-8%] h-[380px] w-[380px] rounded-full bg-gold/15 blur-[120px]"
        aria-hidden
      />

      <div className="relative mx-auto grid max-w-6xl items-center gap-12 px-5 sm:px-8 lg:grid-cols-[1.05fr_0.95fr]">
        <div className="animate-rise">
          <span className="inline-flex items-center gap-2 rounded-full border border-ink-foreground/15 bg-ink-foreground/5 px-4 py-1.5 text-xs font-semibold uppercase tracking-wider text-gold-soft">
            <span className="h-1.5 w-1.5 rounded-full bg-gold animate-pulse-dot" />
            Built for P&amp;C agencies on HawkSoft &amp; EZLynx
          </span>

          <h1 className="mt-6 font-display text-4xl font-bold leading-[1.05] tracking-tight text-ink-foreground sm:text-5xl lg:text-6xl">
            Your producers are quoting{" "}
            <span className="text-ink-muted">40%</span> of what they could.
            <br className="hidden sm:block" /> We give you the other{" "}
            <span className="text-gradient-emerald font-semibold">60% back</span> — without hiring.
          </h1>

          <p className="mt-6 max-w-xl text-base leading-relaxed text-ink-muted sm:text-lg">
            Every week, your team loses hours to slow lead response, forgotten follow-ups, renewals
            that slip, and cross-sell nobody chases. ARK runs the systems behind your agency so leads
            get worked, quotes get followed up, renewals get protected, and your book actually gets
            sold into.
          </p>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Button variant="hero" size="xl" asChild>
              <a href="#pricing">
                Book a Free Discovery Call <ArrowRight className="h-5 w-5" />
              </a>
            </Button>
            <Button variant="inkOutline" size="xl" asChild>
              <a href="#systems">See what ARK does</a>
            </Button>
          </div>

          <div className="mt-6 flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-ink-muted">
            <span className="inline-flex items-center gap-2">
              <Check className="h-4 w-4 text-emerald" /> Live in ~2 weeks
            </span>
            <span className="inline-flex items-center gap-2">
              <Check className="h-4 w-4 text-emerald" /> No rip &amp; replace
            </span>
            <span className="inline-flex items-center gap-2">
              <Check className="h-4 w-4 text-emerald" /> Managed for you
            </span>
          </div>
        </div>

        {/* Live activity feed mock */}
        <div className="animate-rise [animation-delay:120ms]">
          <div className="rounded-3xl border border-ink-foreground/10 bg-ink-foreground/[0.04] p-5 shadow-[var(--shadow-elegant)] backdrop-blur-sm">
            <div className="flex items-center justify-between border-b border-ink-foreground/10 pb-4">
              <div className="flex items-center gap-2">
                <span className="grid h-9 w-9 place-items-center rounded-lg bg-gradient-emerald text-emerald-foreground">
                  <Zap className="h-4 w-4" strokeWidth={2.4} />
                </span>
                <div>
                  <p className="text-sm font-semibold text-ink-foreground">ARK Live Activity</p>
                  <p className="text-xs text-ink-muted">After hours · working while you sleep</p>
                </div>
              </div>
              <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald/15 px-2.5 py-1 text-xs font-semibold text-emerald-foreground">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald animate-pulse-dot" /> Active
              </span>
            </div>

            <ul className="mt-4 space-y-2.5">
              {feed.map((f, i) => (
                <li
                  key={i}
                  className="flex items-start gap-3 rounded-xl border border-ink-foreground/10 bg-ink/40 p-3"
                >
                  <span className="mt-0.5 shrink-0 rounded-md bg-ink-foreground/10 px-2 py-1 text-[11px] font-semibold tabular-nums text-ink-muted">
                    {f.time}
                  </span>
                  <span className="text-sm leading-snug text-ink-foreground/90">{f.text}</span>
                  {f.tone === "win" && (
                    <Check className="ml-auto mt-0.5 h-4 w-4 shrink-0 text-emerald" />
                  )}
                </li>
              ))}
            </ul>

            <div className="mt-4 flex items-center justify-between rounded-xl bg-gradient-emerald px-4 py-3 text-emerald-foreground">
              <span className="inline-flex items-center gap-2 text-sm font-semibold">
                <Clock className="h-4 w-4" /> Response time
              </span>
              <span className="font-display text-2xl font-semibold">&lt;60s</span>
            </div>
          </div>
        </div>
      </div>

      {/* Stats strip */}
      <div className="relative mx-auto mt-16 max-w-6xl px-5 sm:px-8">
        <div className="grid gap-px overflow-hidden rounded-2xl border border-ink-foreground/10 bg-ink-foreground/10 sm:grid-cols-3">
          {stats.map((s) => (
            <div key={s.value} className="bg-ink p-6 sm:p-7">
              <p className="font-display text-4xl font-semibold text-gold sm:text-5xl">{s.value}</p>
              <p className="mt-2 text-sm leading-snug text-ink-muted">{s.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
